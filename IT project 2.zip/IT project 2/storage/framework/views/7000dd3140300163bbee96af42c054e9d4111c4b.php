<html xmlns:v="urn:schemas-microsoft-com:vml"
      xmlns:o="urn:schemas-microsoft-com:office:office"
      xmlns:x="urn:schemas-microsoft-com:office:excel"
      xmlns="http://www.w3.org/TR/REC-html40">

<head>
    <meta http-equiv=Content-Type content="text/html; charset=windows-1252">
    <meta name=ProgId content=Excel.Sheet>
    <meta name=Generator content="Microsoft Excel 15">
    <link rel=File-List href="Template_files/filelist.xml">
    <!--[if !mso]>
    <style>
        v\:* {behavior:url(#default#VML);}
        o\:* {behavior:url(#default#VML);}
        x\:* {behavior:url(#default#VML);}
        .shape {behavior:url(#default#VML);}
    </style>
    <![endif]-->
    <style id="Template_18037_Styles">
        <!--table
        {mso-displayed-decimal-separator:"\.";
            mso-displayed-thousand-separator:"\,";}
        html{
            size: 8.5in 14in;
            margin: 15px 40px;
        }
        .font518037
        {color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;}
        .font618037
        {color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;}
        .xl6418037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:italic;
            text-decoration:none;
            font-family:Calibri, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:general;
            vertical-align:top;
            border-top:none;
            border-right:none;
            border-bottom:none;
            border-left:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl6518037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:left;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl6618037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:left;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl6718037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:normal;}
        .xl6818037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:general;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:nowrap;}
        .xl6918037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:general;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:nowrap;}
        .xl7018037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:general;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:1.0pt solid windowtext;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:nowrap;}
        .xl7118037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:general;
            vertical-align:middle;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:nowrap;}
        .xl7218037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:nowrap;}
        .xl7318037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:nowrap;}
        .xl7418037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:Calibri, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:general;
            vertical-align:middle;
            border-top:1.0pt solid windowtext;
            border-right:none;
            border-bottom:none;
            border-left:.5pt solid windowtext;
            background:white;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl7518037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:Calibri, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:general;
            vertical-align:middle;
            border-top:1.0pt solid windowtext;
            border-right:none;
            border-bottom:none;
            border-left:none;
            background:white;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl7618037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:Calibri, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:general;
            vertical-align:middle;
            border-top:1.0pt solid windowtext;
            border-right:1.0pt solid windowtext;
            border-bottom:none;
            border-left:none;
            background:white;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl7718037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:Calibri, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:none;
            border-left:.5pt solid windowtext;
            background:white;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl7818037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:Calibri, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:center;
            vertical-align:middle;
            background:white;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl7918037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:Calibri, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:left;
            vertical-align:middle;
            background:white;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl8018037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:Calibri, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:1.0pt solid windowtext;
            border-bottom:none;
            border-left:none;
            background:white;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl8118037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:Calibri, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:general;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:.5pt solid windowtext;
            background:white;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl8218037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:Calibri, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:general;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            background:white;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl8318037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:general;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            background:white;
            mso-pattern:black none;
            mso-protection:unlocked visible;
            white-space:nowrap;}
        .xl8418037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:general;
            vertical-align:middle;
            border-top:none;
            border-right:1.0pt solid windowtext;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            background:white;
            mso-pattern:black none;
            mso-protection:unlocked visible;
            white-space:nowrap;}
        .xl8518037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"Short Date";
            text-align:center;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:normal;}
        .xl8618037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"Short Date";
            text-align:center;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:1.0pt solid windowtext;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:normal;}
        .xl8718037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:8.0pt;
            font-weight:700;
            font-style:italic;
            text-decoration:none;
            font-family:Arial, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:left;
            vertical-align:top;
            border-top:none;
            border-right:none;
            border-bottom:none;
            border-left:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:normal;}
        .xl8818037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:8.0pt;
            font-weight:700;
            font-style:italic;
            text-decoration:none;
            font-family:Arial, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:left;
            vertical-align:top;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:normal;}
        .xl8918037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:8.0pt;
            font-weight:700;
            font-style:italic;
            text-decoration:none;
            font-family:Arial, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:left;
            vertical-align:top;
            border-top:none;
            border-right:.5pt solid windowtext;
            border-bottom:none;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:normal;}
        .xl9018037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:8.0pt;
            font-weight:700;
            font-style:italic;
            text-decoration:none;
            font-family:Arial, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:left;
            vertical-align:bottom;
            border-top:none;
            border-right:none;
            border-bottom:none;
            border-left:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl9118037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:8.0pt;
            font-weight:700;
            font-style:italic;
            text-decoration:none;
            font-family:Arial, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:left;
            vertical-align:bottom;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl9218037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:8.0pt;
            font-weight:700;
            font-style:italic;
            text-decoration:none;
            font-family:Arial, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:left;
            vertical-align:bottom;
            border-top:none;
            border-right:.5pt solid windowtext;
            border-bottom:none;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl9318037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:.5pt solid windowtext;
            background:#969696;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl9418037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            background:#969696;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl9518037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:.5pt solid windowtext;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            background:#969696;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl9618037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:Calibri, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:general;
            vertical-align:middle;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl9718037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:italic;
            text-decoration:none;
            font-family:Calibri, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:general;
            vertical-align:bottom;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:none;
            border-left:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl9818037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:general;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:none;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl9918037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:italic;
            text-decoration:none;
            font-family:Arial, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:right;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:.5pt solid windowtext;
            border-bottom:none;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl10018037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Black", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:general;
            vertical-align:top;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl10118037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Black", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:center;
            vertical-align:top;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl10218037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Black", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:general;
            vertical-align:top;
            border-top:none;
            border-right:.5pt solid windowtext;
            border-bottom:none;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl10318037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:Calibri, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:left;
            vertical-align:middle;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl10418037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:left;
            vertical-align:middle;
            border:.5pt solid windowtext;
            background:#757171;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl10518037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:Calibri, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:left;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            background:#757171;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl10618037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:right;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:normal;}
        .xl10718037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:Calibri, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:right;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:normal;}
        .xl10818037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:Calibri, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:right;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:.5pt solid windowtext;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:normal;}
        .xl10918037
        {padding:0px;
            mso-ignore:padding;
            color:white;
            font-size:9.0pt;
            font-weight:700;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:left;
            vertical-align:top;
            border-top:none;
            border-right:none;
            border-bottom:1.0pt solid windowtext;
            border-left:1.0pt solid windowtext;
            background:#969696;
            mso-pattern:black none;
            white-space:normal;}
        .xl11018037
        {padding:0px;
            mso-ignore:padding;
            color:white;
            font-size:9.0pt;
            font-weight:700;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:left;
            vertical-align:top;
            border-top:none;
            border-right:none;
            border-bottom:1.0pt solid windowtext;
            border-left:none;
            background:#969696;
            mso-pattern:black none;
            white-space:normal;}
        .xl11118037
        {padding:0px;
            mso-ignore:padding;
            color:white;
            font-size:9.0pt;
            font-weight:700;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:left;
            vertical-align:top;
            border-top:none;
            border-right:1.0pt solid windowtext;
            border-bottom:1.0pt solid windowtext;
            border-left:none;
            background:#969696;
            mso-pattern:black none;
            white-space:normal;}
        .xl11218037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:right;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:none;
            border-left:1.0pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl11318037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:1.0pt solid windowtext;
            border-right:none;
            border-bottom:none;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl11418037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:1.0pt solid windowtext;
            border-right:.5pt solid windowtext;
            border-bottom:none;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl11518037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:1.0pt solid windowtext;
            border-right:.5pt solid windowtext;
            border-bottom:.5pt solid windowtext;
            border-left:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:nowrap;}
        .xl11618037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:1.0pt solid windowtext;
            border-right:1.0pt solid windowtext;
            border-bottom:.5pt solid windowtext;
            border-left:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:nowrap;}
        .xl11718037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl11818037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:none;
            border-right:.5pt solid windowtext;
            border-bottom:none;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl11918037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:general;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:nowrap;}
        .xl12018037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:general;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:nowrap;}
        .xl12118037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:top;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:.5pt solid windowtext;
            background:#EAEAEA;
            mso-pattern:black none;
            mso-protection:unlocked visible;
            white-space:nowrap;}
        .xl12218037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:top;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            background:#EAEAEA;
            mso-pattern:black none;
            mso-protection:unlocked visible;
            white-space:nowrap;}
        .xl12318037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:top;
            border-top:.5pt solid windowtext;
            border-right:1.0pt solid windowtext;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            background:#EAEAEA;
            mso-pattern:black none;
            mso-protection:unlocked visible;
            white-space:nowrap;}
        .xl12418037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:right;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:1.0pt solid windowtext;
            border-left:1.0pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl12518037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:1.0pt solid windowtext;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl12618037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:none;
            border-right:.5pt solid windowtext;
            border-bottom:1.0pt solid windowtext;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl12718037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:general;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:1.0pt solid windowtext;
            border-left:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:nowrap;}
        .xl12818037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:general;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:1.0pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:nowrap;}
        .xl12918037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:Calibri, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:general;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:1.0pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl13018037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:Calibri, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:general;
            vertical-align:middle;
            border-top:none;
            border-right:1.0pt solid windowtext;
            border-bottom:1.0pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl13118037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:top;
            border-top:1.0pt solid windowtext;
            border-right:none;
            border-bottom:none;
            border-left:1.0pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        .xl13218037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:top;
            border-top:1.0pt solid windowtext;
            border-right:none;
            border-bottom:none;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        .xl13318037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:top;
            border-top:1.0pt solid windowtext;
            border-right:.5pt solid windowtext;
            border-bottom:none;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        .xl13418037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"Short Date";
            text-align:center;
            vertical-align:middle;
            border-top:1.0pt solid windowtext;
            border-right:.5pt solid windowtext;
            border-bottom:none;
            border-left:.5pt solid windowtext;
            background:white;
            mso-pattern:black none;
            mso-protection:unlocked visible;
            white-space:normal;}
        .xl13518037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"Short Date";
            text-align:center;
            vertical-align:middle;
            border-top:1.0pt solid windowtext;
            border-right:1.0pt solid windowtext;
            border-bottom:none;
            border-left:.5pt solid windowtext;
            background:white;
            mso-pattern:black none;
            mso-protection:unlocked visible;
            white-space:normal;}
        .xl13618037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:1.0pt solid windowtext;
            border-right:none;
            border-bottom:none;
            border-left:1.0pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl13718037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl13818037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"Short Date";
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:.5pt solid windowtext;
            background:white;
            mso-pattern:black none;
            mso-protection:unlocked visible;
            white-space:normal;}
        .xl13918037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"Short Date";
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            background:white;
            mso-pattern:black none;
            mso-protection:unlocked visible;
            white-space:normal;}
        .xl14018037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:none;
            border-left:1.0pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl14118037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:right;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:1.0pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl14218037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:general;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl14318037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:.5pt solid windowtext;
            border-bottom:none;
            border-left:.5pt solid windowtext;
            background:white;
            mso-pattern:black none;
            mso-protection:unlocked visible;
            white-space:nowrap;}
        .xl14418037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:none;
            border-left:.5pt solid windowtext;
            background:white;
            mso-pattern:black none;
            mso-protection:unlocked visible;
            white-space:nowrap;}
        .xl14518037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:none;
            border-left:1.0pt solid windowtext;
            background:#EAEAEA;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl14618037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:center;
            vertical-align:middle;
            background:#EAEAEA;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl14718037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:general;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:.5pt solid windowtext;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl14818037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:center;
            vertical-align:top;
            border-top:none;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:1.0pt solid windowtext;
            background:#EAEAEA;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl14918037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:center;
            vertical-align:top;
            border-top:none;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            background:#EAEAEA;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl15018037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:center;
            vertical-align:top;
            border-top:none;
            border-right:.5pt solid windowtext;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            background:#EAEAEA;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl15118037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:Calibri, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:general;
            vertical-align:middle;
            border-top:none;
            border-right:1.0pt solid windowtext;
            border-bottom:none;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl15218037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:none;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl15318037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:.5pt solid windowtext;
            border-bottom:none;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl15418037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:general;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:none;
            border-left:1.0pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl15518037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:general;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:none;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl15618037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid #A6A6A6;
            border-left:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl15718037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid #A6A6A6;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl15818037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:1.0pt solid windowtext;
            border-bottom:.5pt solid #A6A6A6;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl15918037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:left;
            vertical-align:middle;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl16018037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:left;
            vertical-align:middle;
            border-top:none;
            border-right:.5pt solid windowtext;
            border-bottom:none;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl16118037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:general;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:none;
            border-left:1.0pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl16218037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:general;
            vertical-align:middle;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl16318037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:400;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:.5pt solid windowtext;
            background:white;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl16418037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:400;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            background:white;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl16518037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:400;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:1.0pt solid windowtext;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            background:white;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl16618037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:right;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:none;
            border-left:1.0pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl16718037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:right;
            vertical-align:middle;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl16818037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:none;
            border-left:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl16918037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:Calibri, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:general;
            vertical-align:bottom;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:none;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl17018037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:none;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl17118037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:Arial, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:general;
            vertical-align:bottom;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:none;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl17218037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:Arial, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:general;
            vertical-align:bottom;
            border-top:.5pt solid windowtext;
            border-right:1.0pt solid windowtext;
            border-bottom:none;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl17318037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:right;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:1.0pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl17418037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:right;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl17518037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:general;
            vertical-align:middle;
            border-top:none;
            border-right:.5pt solid windowtext;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl17618037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:general;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:nowrap;}
        .xl17718037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:nowrap;}
        .xl17818037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl17918037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:400;
            font-style:italic;
            text-decoration:none;
            font-family:Arial, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:general;
            vertical-align:bottom;
            border-top:none;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl18018037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:400;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            background:white;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl18118037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:Calibri, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:general;
            vertical-align:bottom;
            border-top:none;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl18218037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:Calibri, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:general;
            vertical-align:bottom;
            border-top:none;
            border-right:1.0pt solid windowtext;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl18318037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:none;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl18418037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:.5pt solid windowtext;
            border-bottom:none;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl18518037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:nowrap;}
        .xl18618037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:right;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:1.0pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl18718037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl18818037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:none;
            border-right:.5pt solid windowtext;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl18918037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:nowrap;}
        .xl19018037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:none;
            border-left:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl19118037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl19218037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:400;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            background:white;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl19318037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:400;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:1.0pt solid windowtext;
            border-bottom:none;
            border-left:none;
            background:white;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl19418037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl19518037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:.5pt solid windowtext;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl19618037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:nowrap;}
        .xl19718037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:1.0pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        .xl19818037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:.5pt solid windowtext;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        .xl19918037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:general;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:normal;}
        .xl20018037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:general;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:normal;}
        .xl20118037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:general;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:1.0pt solid windowtext;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:normal;}
        .xl20218037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:none;
            border-left:1.0pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl20318037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:none;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:nowrap;}
        .xl20418037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid #A6A6A6;
            border-left:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl20518037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid #A6A6A6;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl20618037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:1.0pt solid windowtext;
            border-bottom:.5pt solid #A6A6A6;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl20718037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:1.0pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl20818037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:none;
            border-left:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:nowrap;}
        .xl20918037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:1.0pt solid windowtext;
            border-bottom:none;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:nowrap;}
        .xl21018037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid #A6A6A6;
            border-left:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl21118037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid #A6A6A6;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl21218037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:nowrap;}
        .xl21318037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:none;
            border-right:1.0pt solid windowtext;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:nowrap;}
        .xl21418037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:.5pt solid #A6A6A6;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl21518037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:400;
            font-style:italic;
            text-decoration:none;
            font-family:Arial, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:general;
            vertical-align:bottom;
            border-top:.5pt solid #A6A6A6;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl21618037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:400;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:.5pt solid #A6A6A6;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            background:white;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl21718037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:400;
            font-style:italic;
            text-decoration:none;
            font-family:Arial, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:general;
            vertical-align:bottom;
            border-top:.5pt solid #A6A6A6;
            border-right:1.0pt solid windowtext;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl21818037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:general;
            vertical-align:middle;
            border-top:none;
            border-right:.5pt solid windowtext;
            border-bottom:none;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl21918037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl22018037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:1.0pt solid windowtext;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl22118037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl22218037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl22318037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:700;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            background:white;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl22418037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:700;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:1.0pt solid windowtext;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            background:white;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl22518037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:normal;}
        .xl22618037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:normal;}
        .xl22718037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:1.0pt solid windowtext;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:normal;}
        .xl22818037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:.5pt solid windowtext;
            border-bottom:.5pt solid windowtext;
            border-left:1.0pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl22918037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border:.5pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl23018037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:general;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:1.0pt solid windowtext;
            background:#EAEAEA;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl23118037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:Arial, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:general;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            background:#EAEAEA;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl23218037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:left;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:none;
            border-left:1.0pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl23318037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:Calibri, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:general;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:.5pt solid windowtext;
            border-bottom:none;
            border-left:none;
            background:#EAEAEA;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl23418037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:1.0pt solid windowtext;
            border-left:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:normal;}
        .xl23518037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:1.0pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:normal;}
        .xl23618037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:1.0pt solid windowtext;
            border-bottom:1.0pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:normal;}
        .xl23718037
        {padding:0px;
            mso-ignore:padding;
            color:white;
            font-size:9.0pt;
            font-weight:700;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:1.0pt solid windowtext;
            border-right:none;
            border-bottom:none;
            border-left:1.0pt solid windowtext;
            background:#969696;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl23818037
        {padding:0px;
            mso-ignore:padding;
            color:white;
            font-size:9.0pt;
            font-weight:700;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:1.0pt solid windowtext;
            border-right:none;
            border-bottom:none;
            border-left:none;
            background:#969696;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl23918037
        {padding:0px;
            mso-ignore:padding;
            color:white;
            font-size:9.0pt;
            font-weight:700;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:1.0pt solid windowtext;
            border-right:1.0pt solid windowtext;
            border-bottom:none;
            border-left:none;
            background:#969696;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl24018037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:general;
            vertical-align:middle;
            border-top:1.0pt solid windowtext;
            border-right:none;
            border-bottom:none;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl24118037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:general;
            vertical-align:middle;
            border-top:1.0pt solid windowtext;
            border-right:.5pt solid windowtext;
            border-bottom:none;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl24218037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:left;
            vertical-align:middle;
            border-top:1.0pt solid windowtext;
            border-right:.5pt solid windowtext;
            border-bottom:.5pt solid windowtext;
            border-left:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:normal;}
        .xl24318037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:1.0pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        .xl24418037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:1.0pt solid windowtext;
            border-right:.5pt solid windowtext;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        .xl24518037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:1.0pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:.5pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        .xl24618037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:1.0pt solid windowtext;
            border-right:1.0pt solid windowtext;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        .xl24718037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:normal;}
        .xl24818037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:normal;}
        .xl24918037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:.5pt solid windowtext;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:normal;}
        .xl25018037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:left;
            vertical-align:top;
            border:.5pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            mso-protection:unlocked visible;
            white-space:normal;}
        .xl25118037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:1.0pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl25218037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:general;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl25318037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:general;
            vertical-align:middle;
            border-top:none;
            border-right:.5pt solid windowtext;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl25418037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:center;
            vertical-align:top;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:normal;}
        .xl25518037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:center;
            vertical-align:top;
            border-top:.5pt solid windowtext;
            border-right:.5pt solid windowtext;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:normal;}
        .xl25618037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:general;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:1.0pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl25718037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:general;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:.5pt solid windowtext;
            border-bottom:none;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl25818037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:none;
            border-left:1.0pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl25918037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:none;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl26018037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:left;
            vertical-align:middle;
            border:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:normal;}
        .xl26118037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border:.5pt solid windowtext;
            background:white;
            mso-pattern:black none;
            mso-protection:unlocked visible;
            white-space:nowrap;}
        .xl26218037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border:.5pt solid windowtext;
            background:white;
            mso-pattern:black none;
            mso-protection:unlocked visible;
            white-space:nowrap;}
        .xl26318037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:1.0pt solid windowtext;
            border-left:1.0pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl26418037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:.5pt solid windowtext;
            border-bottom:1.0pt solid windowtext;
            border-left:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:normal;}
        .xl26518037
        {padding:0px;
            mso-ignore:padding;
            color:red;
            font-size:9.0pt;
            font-weight:700;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:1.0pt solid windowtext;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        .xl26618037
        {padding:0px;
            mso-ignore:padding;
            color:red;
            font-size:9.0pt;
            font-weight:700;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:1.0pt solid windowtext;
            border-bottom:1.0pt solid windowtext;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        .xl26718037
        {padding:0px;
            mso-ignore:padding;
            color:white;
            font-size:9.0pt;
            font-weight:700;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:none;
            border-left:1.0pt solid windowtext;
            background:#969696;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl26818037
        {padding:0px;
            mso-ignore:padding;
            color:white;
            font-size:9.0pt;
            font-weight:700;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:1.0pt solid windowtext;
            border-left:1.0pt solid windowtext;
            background:#969696;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl26918037
        {padding:0px;
            mso-ignore:padding;
            color:white;
            font-size:9.0pt;
            font-weight:700;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:1.0pt solid windowtext;
            border-left:none;
            background:#969696;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl27018037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:1.0pt solid windowtext;
            border-left:none;
            background:#969696;
            mso-pattern:black none;
            white-space:normal;}
        .xl27118037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:1.0pt solid windowtext;
            border-bottom:1.0pt solid windowtext;
            border-left:none;
            background:#969696;
            mso-pattern:black none;
            white-space:normal;}
        .xl27218037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:1.0pt solid windowtext;
            border-right:none;
            border-bottom:none;
            border-left:1.0pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl27318037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:1.0pt solid windowtext;
            border-right:none;
            border-bottom:none;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl27418037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:1.0pt solid windowtext;
            border-right:none;
            border-bottom:none;
            border-left:.5pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        .xl27518037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:1.0pt solid windowtext;
            border-right:none;
            border-bottom:none;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        .xl27618037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:1.0pt solid windowtext;
            border-right:.5pt solid windowtext;
            border-bottom:none;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        .xl27718037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:1.0pt solid windowtext;
            border-right:1.0pt solid windowtext;
            border-bottom:none;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        .xl27818037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:Arial, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:center;
            vertical-align:middle;
            border-top:1.0pt solid windowtext;
            border-right:.5pt solid windowtext;
            border-bottom:none;
            border-left:.5pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        .xl27918037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:1.0pt solid windowtext;
            border-right:1.0pt solid windowtext;
            border-bottom:none;
            border-left:.5pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        .xl28018037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:none;
            border-left:1.0pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl28118037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl28218037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:none;
            border-left:.5pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        .xl28318037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        .xl28418037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:.5pt solid windowtext;
            border-bottom:none;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        .xl28518037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:1.0pt solid windowtext;
            border-bottom:none;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        .xl28618037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        .xl28718037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:1.0pt solid windowtext;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        .xl28818037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:Arial, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:.5pt solid windowtext;
            border-bottom:none;
            border-left:.5pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        .xl28918037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:1.0pt solid windowtext;
            border-bottom:none;
            border-left:.5pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        .xl29018037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:.5pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        .xl29118037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:.5pt solid windowtext;
            border-bottom:none;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        .xl29218037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:1.0pt solid windowtext;
            border-bottom:none;
            border-left:.5pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        .xl29318037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:general;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:1.0pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        .xl29418037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:general;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:none;
            border-left:1.0pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        .xl29518037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:general;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:.5pt solid windowtext;
            border-bottom:none;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        .xl29618037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:.5pt solid windowtext;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:normal;}
        .xl29718037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:normal;}
        .xl29818037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:normal;}
        .xl29918037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:normal;}
        .xl30018037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:.5pt solid windowtext;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:normal;}
        .xl30118037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:left;
            vertical-align:middle;
            border:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:normal;}
        .xl30218037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:normal;}
        .xl30318037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:1.0pt solid windowtext;
            border-bottom:.5pt solid windowtext;
            border-left:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:normal;}
        .xl30418037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:.5pt solid windowtext;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:normal;}
        .xl30518037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:normal;}
        .xl30618037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:normal;}
        .xl30718037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:normal;}
        .xl30818037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:.5pt solid windowtext;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:normal;}
        .xl30918037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:.5pt solid windowtext;
            border-bottom:none;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:normal;}
        .xl31018037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:.5pt solid windowtext;
            border-bottom:none;
            border-left:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:normal;}
        .xl31118037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:none;
            border-left:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:normal;}
        .xl31218037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:none;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:normal;}
        .xl31318037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:.5pt solid windowtext;
            border-bottom:none;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:normal;}
        .xl31418037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:.5pt solid windowtext;
            border-bottom:none;
            border-left:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:normal;}
        .xl31518037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:.5pt solid windowtext;
            border-bottom:none;
            border-left:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:normal;}
        .xl31618037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:1.0pt solid windowtext;
            border-bottom:none;
            border-left:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:normal;}
        .xl31718037
        {padding:0px;
            mso-ignore:padding;
            color:red;
            font-size:9.0pt;
            font-weight:700;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:1.0pt solid windowtext;
            border-right:none;
            border-bottom:1.0pt solid windowtext;
            border-left:1.0pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl31818037
        {padding:0px;
            mso-ignore:padding;
            color:red;
            font-size:9.0pt;
            font-weight:700;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:1.0pt solid windowtext;
            border-right:none;
            border-bottom:1.0pt solid windowtext;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl31918037
        {padding:0px;
            mso-ignore:padding;
            color:red;
            font-size:9.0pt;
            font-weight:700;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:1.0pt solid windowtext;
            border-right:1.0pt solid windowtext;
            border-bottom:1.0pt solid windowtext;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl32018037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:700;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:1.0pt solid windowtext;
            border-left:1.0pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        .xl32118037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:700;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:1.0pt solid windowtext;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        .xl32218037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:700;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:1.0pt solid windowtext;
            border-bottom:1.0pt solid windowtext;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        .xl32318037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:Arial, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:general;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:1.0pt solid windowtext;
            border-left:1.0pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:normal;}
        .xl32418037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:Arial, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:general;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:1.0pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:normal;}
        .xl32518037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:Arial, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:general;
            vertical-align:middle;
            border-top:none;
            border-right:1.0pt solid windowtext;
            border-bottom:1.0pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:normal;}
        .xl32618037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:700;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:1.0pt solid windowtext;
            border-bottom:1.0pt solid windowtext;
            border-left:1.0pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl32718037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:700;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:1.0pt solid windowtext;
            border-left:1.0pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl32818037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:700;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:1.0pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl32918037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:700;
            font-style:italic;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:1.0pt solid windowtext;
            border-bottom:1.0pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl33018037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\[ENG\]\[$-409\]mmmm\\ d\\\,\\ yyyy\;\@";
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:1.0pt solid windowtext;
            border-left:1.0pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:nowrap;}
        .xl33118037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\[ENG\]\[$-409\]mmmm\\ d\\\,\\ yyyy\;\@";
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:1.0pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:nowrap;}
        .xl33218037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:700;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\[ENG\]\[$-409\]mmmm\\ d\\\,\\ yyyy\;\@";
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:1.0pt solid windowtext;
            border-bottom:1.0pt solid windowtext;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:nowrap;}
        .xl33318037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:left;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:none;
            border-left:.5pt solid windowtext;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl33418037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:left;
            vertical-align:middle;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl33518037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:left;
            vertical-align:middle;
            border-top:none;
            border-right:.5pt solid windowtext;
            border-bottom:none;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            white-space:nowrap;}
        .xl33618037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:1.0pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl33718037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:.5pt solid windowtext;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl33818037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:1.0pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl33918037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:none;
            border-left:1.0pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl34018037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:Arial, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:center;
            vertical-align:top;
            border-top:1.0pt solid windowtext;
            border-right:.5pt solid windowtext;
            border-bottom:none;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        .xl34118037
        {padding:0px;
            mso-ignore:padding;
            color:windowtext;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:Arial, sans-serif;
            mso-font-charset:0;
            mso-number-format:General;
            text-align:center;
            vertical-align:top;
            border-top:none;
            border-right:.5pt solid windowtext;
            border-bottom:none;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        .xl34218037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:none;
            border-left:1.0pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        .xl34318037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:none;
            border-right:none;
            border-bottom:none;
            border-left:1.0pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        .xl34418037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:1.0pt solid windowtext;
            border-left:1.0pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl34518037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:center;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:.5pt solid windowtext;
            border-bottom:1.0pt solid windowtext;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:nowrap;}
        .xl34618037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:none;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:nowrap;}
        .xl34718037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:1.0pt solid windowtext;
            border-bottom:none;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:nowrap;}
        .xl34818037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:none;
            border-right:1.0pt solid windowtext;
            border-bottom:none;
            border-left:none;
            mso-background-source:auto;
            mso-pattern:auto;
            mso-protection:unlocked visible;
            white-space:nowrap;}
        .xl34918037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:none;
            border-bottom:.5pt solid windowtext;
            border-left:1.0pt solid windowtext;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        .xl35018037
        {padding:0px;
            mso-ignore:padding;
            color:black;
            font-size:9.0pt;
            font-weight:400;
            font-style:normal;
            text-decoration:none;
            font-family:"Arial Narrow", sans-serif;
            mso-font-charset:0;
            mso-number-format:"\@";
            text-align:left;
            vertical-align:middle;
            border-top:.5pt solid windowtext;
            border-right:.5pt solid windowtext;
            border-bottom:.5pt solid windowtext;
            border-left:none;
            background:silver;
            mso-pattern:black none;
            white-space:normal;}
        -->
    </style>
</head>

<body>
<!--[if !excel]>&nbsp;&nbsp;<![endif]-->
<!--The following information was generated by Microsoft Excel's Publish as Web
Page wizard.-->
<!--If the same item is republished from Excel, all information between the DIV
tags will be replaced.-->
<!----------------------------->
<!--START OF OUTPUT FROM EXCEL PUBLISH AS WEB PAGE WIZARD -->
<!----------------------------->

<div id="Template_18037" align=center x:publishsource="Excel">

    <table border=0 cellpadding=0 cellspacing=0 width=742 class=xl9618037
           style='border-collapse:collapse;table-layout:fixed;width:558pt'>
        <col class=xl9618037 width=17 style='mso-width-source:userset;mso-width-alt:
 621;width:13pt'>
        <col class=xl9618037 width=76 style='mso-width-source:userset;mso-width-alt:
 2779;width:57pt'>
        <col class=xl9618037 width=56 style='mso-width-source:userset;mso-width-alt:
 2048;width:42pt'>
        <col class=xl9618037 width=62 style='mso-width-source:userset;mso-width-alt:
 2267;width:47pt'>
        <col class=xl9618037 width=35 style='mso-width-source:userset;mso-width-alt:
 1280;width:26pt'>
        <col class=xl9618037 width=37 style='mso-width-source:userset;mso-width-alt:
 1353;width:28pt'>
        <col class=xl9618037 width=51 style='mso-width-source:userset;mso-width-alt:
 1865;width:38pt'>
        <col class=xl9618037 width=50 style='mso-width-source:userset;mso-width-alt:
 1828;width:38pt'>
        <col class=xl9618037 width=22 style='mso-width-source:userset;mso-width-alt:
 804;width:17pt'>
        <col class=xl9618037 width=41 style='mso-width-source:userset;mso-width-alt:
 1499;width:31pt'>
        <col class=xl9618037 width=44 style='mso-width-source:userset;mso-width-alt:
 1609;width:33pt'>
        <col class=xl9618037 width=92 style='mso-width-source:userset;mso-width-alt:
 3364;width:69pt'>
        <col class=xl9618037 width=79 style='mso-width-source:userset;mso-width-alt:
 2889;width:59pt'>
        <col class=xl9618037 width=80 style='mso-width-source:userset;mso-width-alt:
 2925;width:60pt'>
        <tr height=10 style='mso-height-source:userset;height:7.5pt'>
            <td colspan=14 height=10 class=xl9318037 width=742 style='border-right:.5pt solid black;
  height:7.5pt;width:558pt'>&nbsp;</td>
        </tr>
        <tr height=15 style='mso-height-source:userset;height:11.25pt'>
            <td height=15 class=xl9718037 colspan=2 style='height:11.25pt'>CS Form No.
                212</td>
            <td class=xl9818037 style='border-top:none'>&nbsp;</td>
            <td class=xl9818037 style='border-top:none'>&nbsp;</td>
            <td class=xl9818037 style='border-top:none'>&nbsp;</td>
            <td class=xl9818037 style='border-top:none'>&nbsp;</td>
            <td class=xl9818037 style='border-top:none'>&nbsp;</td>
            <td class=xl9818037 style='border-top:none'>&nbsp;</td>
            <td class=xl9818037 style='border-top:none'>&nbsp;</td>
            <td class=xl9818037 style='border-top:none'>&nbsp;</td>
            <td class=xl9818037 style='border-top:none'>&nbsp;</td>
            <td class=xl9818037 style='border-top:none'><span
                        style='mso-spacerun:yes'>        </span></td>
            <td class=xl9818037 style='border-top:none'>&nbsp;</td>
            <td class=xl9918037 style='border-top:none'>&nbsp;</td>
        </tr>
        <tr height=40 style='mso-height-source:userset;height:30.0pt'>
            <td height=40 class=xl6418037 colspan=2 style='height:30.0pt'>Revised 2017</td>
            <td class=xl10018037></td>
            <td colspan=9 class=xl10118037>PERSONAL DATA SHEET</td>
            <td class=xl10018037></td>
            <td class=xl10218037>&nbsp;</td>
        </tr>
        <tr height=29 style='mso-height-source:userset;height:21.75pt'>
            <td colspan=14 height=29 class=xl8718037 width=742 style='border-right:.5pt solid black;
  height:21.75pt;width:558pt'>WARNING: Any misinterpretation made in the
                Personal Data Sheet and the Work Experience Sheet shall cause the filing of
                administrative/criminal case/s against the person concerned.</td>
        </tr>
        <tr height=15 style='mso-height-source:userset;height:11.25pt'>
            <td colspan=14 height=15 class=xl9018037 style='border-right:.5pt solid black;
  height:11.25pt'>READ THE ATTACHED GUIDE TO FILLING OUT THE PERSONAL DATA
                SHEET (PDS) BEFORE ACCOMPLISHING THE PDS FORM.</td>
        </tr>
        <tr class=xl10318037 height=18 style='height:13.5pt'>
            <td colspan=14 height=18 class=xl33318037 style='border-right:.5pt solid black;
  height:13.5pt'>Print legibly. Tick appropriate boxes (&#9744;) and use
                separate sheet if necessary. Indicate N/A if not applicable.<span
                        style='mso-spacerun:yes'>  </span><font class="font618037">DO NOT ABBREVIATE.</font></td>
        </tr>
        <tr class=xl10318037 height=16 style='mso-height-source:userset;height:12.0pt'>
            <td height=16 class=xl6518037 style='height:12.0pt'>&nbsp;</td>
            <td class=xl6618037>&nbsp;</td>
            <td class=xl6618037>&nbsp;</td>
            <td class=xl6618037>&nbsp;</td>
            <td class=xl6618037>&nbsp;</td>
            <td class=xl6618037>&nbsp;</td>
            <td class=xl6618037>&nbsp;</td>
            <td class=xl6618037>&nbsp;</td>
            <td class=xl6618037>&nbsp;</td>
            <td class=xl10418037>1. CS ID<span style='display:none'> No.</span></td>
            <td class=xl10518037>&nbsp;</td>
            <td colspan=3 class=xl10618037 width=251 style='border-right:.5pt solid black;
  width:188pt'>&nbsp;</td>
        </tr>
        <tr height=19 style='height:14.25pt'>
            <td colspan=14 height=19 class=xl10918037 width=742 style='border-right:1.0pt solid black;
  height:14.25pt;width:558pt'>I. PERSONAL INFORMATION</td>
        </tr>
        <tr height=18 style='height:13.5pt'>
            <td height=18 class=xl11218037 style='height:13.5pt'>2.</td>
            <td colspan=2 class=xl11318037 style='border-right:.5pt solid black'>SURNAME</td>
            <td colspan=11 class=xl11518037 style='border-right:1.0pt solid black;
  border-left:none'>&nbsp;</td>
        </tr>
        <tr height=18 style='height:13.5pt'>
            <td height=18 class=xl11218037 style='height:13.5pt'>&nbsp;</td>
            <td colspan=2 class=xl11718037 style='border-right:.5pt solid black'>FIRST
                NAME</td>
            <td class=xl11918037 style='border-top:none;border-left:none'>&nbsp;</td>
            <td class=xl12018037 style='border-top:none'>&nbsp;</td>
            <td class=xl12018037 style='border-top:none'>&nbsp;</td>
            <td class=xl12018037 style='border-top:none'>&nbsp;</td>
            <td class=xl12018037 style='border-top:none'>&nbsp;</td>
            <td class=xl12018037 style='border-top:none'>&nbsp;</td>
            <td class=xl12018037 style='border-top:none'>&nbsp;</td>
            <td class=xl12018037 style='border-top:none'>&nbsp;</td>
            <td colspan=3 class=xl12118037 style='border-right:1.0pt solid black'>NAME
                EXTENSION (JR., SR)<span style='mso-spacerun:yes'>             </span><font
                        class="font618037"><span style='mso-spacerun:yes'>    </span></font><font
                        class="font518037"><span style='mso-spacerun:yes'>          </span></font></td>
        </tr>
        <tr height=21 style='mso-height-source:userset;height:15.75pt'>
            <td height=21 class=xl12418037 style='height:15.75pt'>&nbsp;</td>
            <td colspan=2 class=xl12518037 style='border-right:.5pt solid black'>MIDDLE
                NAME</td>
            <td class=xl12718037 style='border-top:none;border-left:none'>&nbsp;</td>
            <td class=xl12818037 style='border-top:none'>&nbsp;</td>
            <td class=xl12818037 style='border-top:none'>&nbsp;</td>
            <td class=xl12818037 style='border-top:none'>&nbsp;</td>
            <td class=xl12818037 style='border-top:none'>&nbsp;</td>
            <td class=xl12818037 style='border-top:none'>&nbsp;</td>
            <td class=xl12818037 style='border-top:none'>&nbsp;</td>
            <td class=xl12818037 style='border-top:none'>&nbsp;</td>
            <td class=xl12918037>&nbsp;</td>
            <td class=xl12918037>&nbsp;</td>
            <td class=xl13018037>&nbsp;</td>
        </tr>
        <tr height=18 style='height:13.5pt'>
            <td colspan=3 height=18 class=xl13118037 width=149 style='border-right:.5pt solid black;
  height:13.5pt;width:112pt'>3. DATE OF BIRTH <br>
            </td>
            <td colspan=3 class=xl13418037 width=134 style='border-right:1.0pt solid black;
  border-left:none;width:101pt'>&nbsp;</td>
            <td class=xl13618037 colspan=2>16. CITIZENSHIP</td>
            <td class=xl11318037 style='border-top:none'>&nbsp;</td>
            <td class=xl7418037 colspan=2>&#9744; Filipino</td>
            <td class=xl7518037 colspan=2>&#9744; Dual Citizenship</td>
            <td class=xl7618037 style='border-top:none'>&nbsp;</td>
        </tr>
        <tr height=16 style='mso-height-source:userset;height:12.0pt'>
            <td height=16 class=xl11218037 style='height:12.0pt'>&nbsp;</td>
            <td class=xl13718037>&nbsp;</td>
            <td class=xl13718037>&nbsp;</td>
            <td class=xl13818037 width=62 style='width:47pt'>&nbsp;</td>
            <td class=xl13918037 width=35 style='width:26pt'>&nbsp;</td>
            <td class=xl13918037 width=37 style='width:28pt'>&nbsp;</td>
            <td class=xl14018037>&nbsp;</td>
            <td class=xl11718037>&nbsp;</td>
            <td class=xl11718037>&nbsp;</td>
            <td class=xl7718037>&nbsp;</td>
            <td class=xl7818037>&nbsp;</td>
            <td class=xl7918037>&#9744; by birth</td>
            <td class=xl7918037 colspan=2 style='border-right:1.0pt solid black'>&#9744;
                by naturalization</td>
        </tr>
        <tr height=18 style='height:13.5pt'>
            <td colspan=3 height=18 class=xl33818037 style='border-right:.5pt solid black;
  height:13.5pt'>4. PLACE OF BIRTH</td>
            <td colspan=3 class=xl14318037 style='border-left:none'>&nbsp;</td>
            <td colspan=3 class=xl14518037>&nbsp;</td>
            <td class=xl8118037>&nbsp;</td>
            <td class=xl8218037>&nbsp;</td>
            <td class=xl8318037 colspan=2>Pls. indicate country:</td>
            <td class=xl8418037>&nbsp;</td>
        </tr>
        <tr height=18 style='height:13.5pt'>
            <td colspan=3 height=18 class=xl33818037 style='border-right:.5pt solid black;
  height:13.5pt'>5. SEX</td>
            <td class=xl6818037 style='border-left:none'>&#9744; Male</td>
            <td class=xl6918037 colspan=2 style='border-right:1.0pt solid black'>&#9744;
                Female</td>
            <td colspan=3 class=xl14818037 style='border-right:.5pt solid black;
  border-left:none'>&nbsp;</td>
            <td class=xl9618037></td>
            <td class=xl9618037></td>
            <td class=xl9618037></td>
            <td class=xl9618037></td>
            <td class=xl15118037>&nbsp;</td>
        </tr>
        <tr height=18 style='height:13.5pt'>
            <td colspan=3 rowspan=2 height=36 class=xl33918037 style='border-right:.5pt solid black;
  height:27.0pt'>6. CIVIL STATUS</td>
            <td class=xl7118037>&#9744; Single</td>
            <td colspan=2 class=xl34618037 style='border-right:1.0pt solid black'>&#9744;
                Married</td>
            <td colspan=2 rowspan=2 class=xl34218037 width=101 style='border-right:.5pt solid black;
  width:76pt'>17. RESIDENTIAL ADDRESS</td>
            <td colspan=3 class=xl15618037 style='border-left:none'>&nbsp;</td>
            <td colspan=3 class=xl15718037 style='border-right:1.0pt solid black'>&nbsp;</td>
        </tr>
        <tr height=18 style='height:13.5pt'>
            <td height=18 class=xl7118037 style='height:13.5pt'>&#9744; Widowed</td>
            <td colspan=2 class=xl7218037 style='border-right:1.0pt solid black'>&#9744;
                Seperated</td>
            <td colspan=3 class=xl16318037 style='border-left:none'>House/Block/Lot No.</td>
            <td colspan=3 class=xl16418037 style='border-right:1.0pt solid black'>Street</td>
        </tr>
        <tr height=18 style='height:13.5pt'>
            <td height=18 class=xl16618037 style='height:13.5pt'>&nbsp;</td>
            <td class=xl16718037>&nbsp;</td>
            <td class=xl16018037>&nbsp;</td>
            <td class=xl7218037>&#9744; Other/s:</td>
            <td class=xl7318037></td>
            <td class=xl7318037></td>
            <td class=xl16118037>&nbsp;</td>
            <td class=xl16218037>&nbsp;</td>
            <td colspan=3 class=xl16818037>&nbsp;</td>
            <td colspan=3 class=xl17018037 style='border-right:1.0pt solid black'>&nbsp;</td>
        </tr>
        <tr height=18 style='height:13.5pt'>
            <td height=18 class=xl17318037 style='height:13.5pt'>&nbsp;</td>
            <td class=xl17418037>&nbsp;</td>
            <td class=xl17518037>&nbsp;</td>
            <td class=xl17618037>&nbsp;</td>
            <td colspan=2 class=xl17718037>&nbsp;</td>
            <td class=xl14018037>&nbsp;</td>
            <td class=xl11718037>&nbsp;</td>
            <td colspan=3 class=xl17818037>Subdivision/Village</td>
            <td colspan=3 class=xl18018037 style='border-right:1.0pt solid black'>Barangay</td>
        </tr>
        <tr height=18 style='height:13.5pt'>
            <td rowspan=2 height=29 class=xl11218037 style='border-bottom:.5pt solid black;
  height:21.75pt'>7.</td>
            <td colspan=2 rowspan=2 class=xl18318037 style='border-right:.5pt solid black;
  border-bottom:.5pt solid black'>HEIGHT<span style='mso-spacerun:yes'> </span></td>
            <td colspan=3 rowspan=2 class=xl18518037 style='border-bottom:.5pt solid black'></td>
            <td class=xl14018037>&nbsp;</td>
            <td class=xl11718037>&nbsp;</td>
            <td colspan=3 class=xl15618037>&nbsp;</td>
            <td colspan=3 class=xl15718037 style='border-right:1.0pt solid black'>&nbsp;</td>
        </tr>
        <tr height=11 style='mso-height-source:userset;height:8.25pt'>
            <td height=11 class=xl14018037 style='height:8.25pt'>&nbsp;</td>
            <td class=xl11718037>&nbsp;</td>
            <td colspan=3 class=xl19018037>City/Municipality</td>
            <td colspan=3 class=xl19218037 style='border-right:1.0pt solid black'>Province</td>
        </tr>
        <tr height=18 style='height:13.5pt'>
            <td height=18 class=xl11218037 style='height:13.5pt'>8.</td>
            <td colspan=2 class=xl19418037 style='border-right:.5pt solid black'>WEIGHT<span
                        style='mso-spacerun:yes'> </span></td>
            <td colspan=3 class=xl19618037>&nbsp;</td>
            <td colspan=2 class=xl19718037 width=101 style='border-right:.5pt solid black;
  width:76pt'>ZIP CODE<span style='mso-spacerun:yes'>    </span></td>
            <td class=xl19918037 width=22 style='border-left:none;width:17pt'>&nbsp;</td>
            <td class=xl20018037 width=41 style='width:31pt'>&nbsp;</td>
            <td class=xl20018037 width=44 style='width:33pt'>&nbsp;</td>
            <td class=xl20018037 width=92 style='width:69pt'>&nbsp;</td>
            <td class=xl20018037 width=79 style='width:59pt'>&nbsp;</td>
            <td class=xl20118037 width=80 style='width:60pt'>&nbsp;</td>
        </tr>
        <tr height=18 style='height:13.5pt'>
            <td rowspan=2 height=30 class=xl20218037 style='border-bottom:.5pt solid black;
  height:22.5pt'>9.</td>
            <td colspan=2 rowspan=2 class=xl18318037 style='border-right:.5pt solid black;
  border-bottom:.5pt solid black'>BLOOD TYPE</td>
            <td colspan=3 rowspan=2 class=xl20318037 style='border-bottom:.5pt solid black'>&nbsp;</td>
            <td colspan=2 rowspan=2 class=xl34218037 width=101 style='border-right:.5pt solid black;
  width:76pt'>18. PERMANENT ADDRESS</td>
            <td colspan=3 class=xl20418037 style='border-left:none'>&nbsp;</td>
            <td colspan=3 class=xl20518037 style='border-right:1.0pt solid black'>&nbsp;</td>
        </tr>
        <tr height=12 style='mso-height-source:userset;height:9.0pt'>
            <td colspan=3 height=12 class=xl16318037 style='height:9.0pt;border-left:
  none'>House/Block/Lot No.</td>
            <td colspan=3 class=xl16418037 style='border-right:1.0pt solid black'>Street</td>
        </tr>
        <tr height=18 style='height:13.5pt'>
            <td rowspan=2 height=30 class=xl20218037 style='border-bottom:.5pt solid black;
  height:22.5pt;border-top:none'>10.</td>
            <td colspan=2 rowspan=2 class=xl18318037 style='border-right:.5pt solid black;
  border-bottom:.5pt solid black'>GSIS ID NO.</td>
            <td colspan=3 rowspan=2 class=xl20818037 style='border-right:1.0pt solid black;
  border-bottom:.5pt solid black'>&nbsp;</td>
            <td class=xl16118037 style='border-left:none'>&nbsp;</td>
            <td class=xl16218037>&nbsp;</td>
            <td colspan=3 class=xl21018037>&nbsp;</td>
            <td colspan=3 class=xl20518037 style='border-right:1.0pt solid black'>&nbsp;</td>
        </tr>
        <tr height=12 style='mso-height-source:userset;height:9.0pt'>
            <td height=12 class=xl16118037 style='height:9.0pt;border-left:none'>&nbsp;</td>
            <td class=xl16218037>&nbsp;</td>
            <td colspan=3 class=xl21418037>Subdivision/Village</td>
            <td colspan=3 class=xl21618037 style='border-right:1.0pt solid black'>Barangay</td>
        </tr>
        <tr height=18 style='height:13.5pt'>
            <td rowspan=2 height=31 class=xl20218037 style='border-bottom:.5pt solid black;
  height:23.25pt;border-top:none'>11.</td>
            <td colspan=2 rowspan=2 class=xl18318037 style='border-right:.5pt solid black;
  border-bottom:.5pt solid black'>PAG-IBIG ID NO.</td>
            <td colspan=3 rowspan=2 class=xl20818037 style='border-right:1.0pt solid black;
  border-bottom:.5pt solid black'>&nbsp;</td>
            <td class=xl16118037 style='border-left:none'>&nbsp;</td>
            <td class=xl21818037>&nbsp;</td>
            <td colspan=3 class=xl15618037 style='border-left:none'>&nbsp;</td>
            <td colspan=3 class=xl15718037 style='border-right:1.0pt solid black'>&nbsp;</td>
        </tr>
        <tr height=13 style='mso-height-source:userset;height:9.75pt'>
            <td height=13 class=xl16118037 style='height:9.75pt;border-left:none'>&nbsp;</td>
            <td class=xl21818037>&nbsp;</td>
            <td colspan=3 class=xl21918037>City/Municipality</td>
            <td colspan=3 class=xl21918037 style='border-right:1.0pt solid black'>Province</td>
        </tr>
        <tr height=18 style='height:13.5pt'>
            <td height=18 class=xl14118037 style='height:13.5pt;border-top:none'>12.</td>
            <td class=xl14218037 colspan=2 style='border-right:.5pt solid black'>PHILHEALTH
                NO.</td>
            <td colspan=3 class=xl20318037>&nbsp;</td>
            <td colspan=2 class=xl19718037 width=101 style='border-right:.5pt solid black;
  width:76pt'>ZIP CODE<span style='mso-spacerun:yes'>    </span></td>
            <td colspan=3 class=xl22118037 style='border-left:none'>&nbsp;</td>
            <td colspan=3 class=xl22318037 style='border-right:1.0pt solid black'>&nbsp;</td>
        </tr>
        <tr height=18 style='height:13.5pt'>
            <td height=18 class=xl11218037 style='height:13.5pt'>13.</td>
            <td class=xl14218037 style='border-top:none'>SSS NO.</td>
            <td class=xl14718037 style='border-top:none'>&nbsp;</td>
            <td colspan=3 class=xl19618037>&nbsp;</td>
            <td colspan=2 class=xl33618037 style='border-right:.5pt solid black'>19.
                TELEPHONE NO.</td>
            <td colspan=6 class=xl22518037 width=358 style='border-right:1.0pt solid black;
  border-left:none;width:269pt'>&nbsp;</td>
        </tr>
        <tr height=18 style='height:13.5pt'>
            <td colspan=3 height=18 class=xl22818037 style='height:13.5pt'>14. TIN NO.</td>
            <td colspan=3 class=xl19618037>&nbsp;</td>
            <td class=xl23018037 colspan=2>20. MOBILE NO.</td>
            <td colspan=6 class=xl22518037 width=358 style='border-right:1.0pt solid black;
  width:269pt'>&nbsp;</td>
        </tr>
        <tr height=19 style='height:14.25pt'>
            <td height=19 class=xl23218037 colspan=2 style='height:14.25pt'>15. AGENCY
                EMPL<span style='display:none'>OYEE NO.</span></td>
            <td class=xl23318037 style='border-top:none'>&nbsp;</td>
            <td colspan=3 class=xl20318037>&nbsp;</td>
            <td colspan=2 class=xl34418037 style='border-right:.5pt solid black'>21.
                E-MAIL ADDRESS</td>
            <td colspan=6 class=xl23418037 width=358 style='border-right:1.0pt solid black;
  border-left:none;width:269pt'>&nbsp;</td>
        </tr>
        <tr height=19 style='height:14.25pt'>
            <td height=19 class=xl23718037 colspan=3 style='height:14.25pt'>II.<span
                        style='mso-spacerun:yes'>  </span>FAMILY BACKGROUND</td>
            <td class=xl23818037>&nbsp;</td>
            <td class=xl23818037>&nbsp;</td>
            <td class=xl23818037>&nbsp;</td>
            <td class=xl23818037 style='border-top:none'>&nbsp;</td>
            <td class=xl23818037 style='border-top:none'>&nbsp;</td>
            <td class=xl23818037 style='border-top:none'>&nbsp;</td>
            <td class=xl23818037 style='border-top:none'>&nbsp;</td>
            <td class=xl23818037 style='border-top:none'>&nbsp;</td>
            <td class=xl23818037 style='border-top:none'>&nbsp;</td>
            <td class=xl23818037 style='border-top:none'>&nbsp;</td>
            <td class=xl23918037 style='border-top:none'>&nbsp;</td>
        </tr>
        <tr height=18 style='height:13.5pt'>
            <td height=18 class=xl13618037 style='height:13.5pt'>22.</td>
            <td class=xl24018037 colspan=2 style='border-right:.5pt solid black'>SPOUSE'S
                SURNAME</td>
            <td colspan=5 class=xl24218037 width=235 style='border-left:none;width:177pt'>&nbsp;</td>
            <td colspan=4 class=xl24318037 width=199 style='border-right:.5pt solid black;
  width:150pt'>23. NAME of CHILDREN</td>
            <td colspan=2 class=xl24518037 width=159 style='border-right:1.0pt solid black;
  border-left:none;width:119pt'>DATE OF BIRTH</td>
        </tr>
        <tr height=18 style='height:13.5pt'>
            <td height=18 class=xl14018037 style='height:13.5pt'>&nbsp;</td>
            <td class=xl16218037><span style='mso-spacerun:yes'>  </span>FIRST NAME</td>
            <td class=xl21818037>&nbsp;</td>
            <td colspan=3 class=xl24718037 width=134 style='border-right:.5pt solid black;
  border-left:none;width:101pt'>&nbsp;</td>
            <td colspan=2 class=xl25018037 width=101 style='border-left:none;width:76pt'>NAME
                EXTENSION (JR., SR)<span
                        style='mso-spacerun:yes'>                                  </span></td>
            <td colspan=4 class=xl24718037 width=199 style='border-right:.5pt solid black;
  border-left:none;width:150pt'>&nbsp;</td>
            <td colspan=2 class=xl8518037 width=159 style='border-right:1.0pt solid black;
  border-left:none;width:119pt'>&nbsp;</td>
        </tr>
        <tr height=18 style='height:13.5pt'>
            <td height=18 class=xl25118037 style='height:13.5pt'>&nbsp;</td>
            <td class=xl25218037 colspan=2 style='border-right:.5pt solid black'><span
                        style='mso-spacerun:yes'>  </span>MIDDLE NAME</td>
            <td colspan=5 class=xl24718037 width=235 style='border-right:.5pt solid black;
  border-left:none;width:177pt'>&nbsp;</td>
            <td colspan=4 class=xl25418037 width=199 style='border-right:.5pt solid black;
  width:150pt'>&nbsp;</td>
            <td colspan=2 class=xl8518037 width=159 style='border-right:1.0pt solid black;
  border-left:none;width:119pt'>&nbsp;</td>
        </tr>
        <tr height=17 style='mso-height-source:userset;height:12.75pt'>
            <td height=17 class=xl25618037 style='height:12.75pt;border-top:none'>&nbsp;</td>
            <td class=xl14218037 style='border-top:none'>OCCUPATION</td>
            <td class=xl14718037 style='border-top:none'>&nbsp;</td>
            <td colspan=5 class=xl24718037 width=235 style='border-right:.5pt solid black;
  border-left:none;width:177pt'>&nbsp;</td>
            <td colspan=4 class=xl25418037 width=199 style='border-right:.5pt solid black;
  width:150pt'>&nbsp;</td>
            <td colspan=2 class=xl8518037 width=159 style='border-right:1.0pt solid black;
  border-left:none;width:119pt'>&nbsp;</td>
        </tr>
        <tr height=28 style='mso-height-source:userset;height:21.0pt'>
            <td height=28 class=xl25618037 style='height:21.0pt;border-top:none'>&nbsp;</td>
            <td class=xl14218037 colspan=2 style='border-right:.5pt solid black'>EMPLOYER/BUSINESS
                N<span style='display:none'>AME</span></td>
            <td colspan=5 class=xl24718037 width=235 style='border-right:.5pt solid black;
  border-left:none;width:177pt'>&nbsp;</td>
            <td colspan=4 class=xl25418037 width=199 style='border-right:.5pt solid black;
  width:150pt'>&nbsp;</td>
            <td colspan=2 class=xl8518037 width=159 style='border-right:1.0pt solid black;
  border-left:none;width:119pt'>&nbsp;</td>
        </tr>
        <tr height=28 style='mso-height-source:userset;height:21.0pt'>
            <td height=28 class=xl25618037 style='height:21.0pt;border-top:none'>&nbsp;</td>
            <td class=xl14218037 colspan=2 style='border-right:.5pt solid black'>BUSINESS
                ADDRESS</td>
            <td colspan=5 class=xl24718037 width=235 style='border-right:.5pt solid black;
  border-left:none;width:177pt'>&nbsp;</td>
            <td colspan=4 class=xl25418037 width=199 style='border-right:.5pt solid black;
  width:150pt'>&nbsp;</td>
            <td colspan=2 class=xl8518037 width=159 style='border-right:1.0pt solid black;
  border-left:none;width:119pt'>&nbsp;</td>
        </tr>
        <tr height=28 style='mso-height-source:userset;height:21.0pt'>
            <td height=28 class=xl15418037 style='height:21.0pt;border-top:none'>&nbsp;</td>
            <td class=xl15518037 colspan=2 style='border-right:.5pt solid black'>TELEPHONE
                NO.</td>
            <td colspan=5 class=xl24718037 width=235 style='border-right:.5pt solid black;
  border-left:none;width:177pt'>&nbsp;</td>
            <td colspan=4 class=xl25418037 width=199 style='border-right:.5pt solid black;
  width:150pt'>&nbsp;</td>
            <td colspan=2 class=xl8518037 width=159 style='border-right:1.0pt solid black;
  border-left:none;width:119pt'>&nbsp;</td>
        </tr>
        <tr height=18 style='height:13.5pt'>
            <td height=18 class=xl25818037 style='height:13.5pt'>24.</td>
            <td class=xl25918037>FATHER'S SURNAME</td>
            <td class=xl15518037>&nbsp;</td>
            <td colspan=5 class=xl26018037 width=235 style='width:177pt'>&nbsp;</td>
            <td colspan=4 class=xl25418037 width=199 style='border-right:.5pt solid black;
  width:150pt'>&nbsp;</td>
            <td colspan=2 class=xl8518037 width=159 style='border-right:1.0pt solid black;
  border-left:none;width:119pt'>&nbsp;</td>
        </tr>
        <tr height=18 style='height:13.5pt'>
            <td height=18 class=xl14018037 style='height:13.5pt'>&nbsp;</td>
            <td class=xl11718037>FIRST NAME</td>
            <td class=xl11718037>&nbsp;</td>
            <td colspan=3 class=xl24718037 width=134 style='border-right:.5pt solid black;
  width:101pt'>&nbsp;</td>
            <td colspan=2 class=xl25018037 width=101 style='border-left:none;width:76pt'>NAME
                EXTENSION (JR., <font class="font618037">SR</font><font class="font518037">)<span
                            style='mso-spacerun:yes'>                                     </span></font></td>
            <td colspan=4 class=xl25418037 width=199 style='border-right:.5pt solid black;
  width:150pt'>&nbsp;</td>
            <td colspan=2 class=xl8518037 width=159 style='border-right:1.0pt solid black;
  border-left:none;width:119pt'>&nbsp;</td>
        </tr>
        <tr height=18 style='height:13.5pt'>
            <td height=18 class=xl25118037 style='height:13.5pt'>&nbsp;</td>
            <td class=xl18718037 colspan=2>MIDDLE NAME</td>
            <td colspan=5 class=xl24718037 width=235 style='border-right:.5pt solid black;
  width:177pt'>&nbsp;</td>
            <td colspan=4 class=xl25418037 width=199 style='border-right:.5pt solid black;
  width:150pt'>&nbsp;</td>
            <td colspan=2 class=xl8518037 width=159 style='border-right:1.0pt solid black;
  border-left:none;width:119pt'>&nbsp;</td>
        </tr>
        <tr height=18 style='height:13.5pt'>
            <td height=18 class=xl14018037 style='height:13.5pt'>25.</td>
            <td class=xl11718037 colspan=2>MOTHER'S MAIDEN NAME</td>
            <td colspan=5 class=xl26118037>&nbsp;</td>
            <td colspan=4 class=xl25418037 width=199 style='border-right:.5pt solid black;
  width:150pt'>&nbsp;</td>
            <td colspan=2 class=xl8518037 width=159 style='border-right:1.0pt solid black;
  border-left:none;width:119pt'>&nbsp;</td>
        </tr>
        <tr height=22 style='mso-height-source:userset;height:16.5pt'>
            <td height=22 class=xl14018037 style='height:16.5pt'>&nbsp;</td>
            <td class=xl11718037>SURNAME</td>
            <td class=xl11718037>&nbsp;</td>
            <td colspan=5 class=xl26218037>&nbsp;</td>
            <td colspan=4 class=xl25418037 width=199 style='border-right:.5pt solid black;
  width:150pt'>&nbsp;</td>
            <td colspan=2 class=xl8518037 width=159 style='border-right:1.0pt solid black;
  border-left:none;width:119pt'>&nbsp;</td>
        </tr>
        <tr height=18 style='height:13.5pt'>
            <td height=18 class=xl14018037 style='height:13.5pt'>&nbsp;</td>
            <td class=xl11718037>FIRST NAME</td>
            <td class=xl11718037>&nbsp;</td>
            <td colspan=5 class=xl26218037>&nbsp;</td>
            <td colspan=4 class=xl25418037 width=199 style='border-right:.5pt solid black;
  width:150pt'>&nbsp;</td>
            <td colspan=2 class=xl8518037 width=159 style='border-right:1.0pt solid black;
  border-left:none;width:119pt'>&nbsp;</td>
        </tr>
        <tr height=19 style='height:14.25pt'>
            <td height=19 class=xl26318037 style='height:14.25pt'>&nbsp;</td>
            <td class=xl12518037 colspan=2>MIDDLE NAME</td>
            <td colspan=5 class=xl26418037 width=235 style='width:177pt'>&nbsp;</td>
            <td colspan=6 class=xl26518037 width=358 style='border-right:1.0pt solid black;
  width:269pt'>&nbsp;</td>
        </tr>
        <tr height=19 style='height:14.25pt'>
            <td height=19 class=xl26718037 style='height:14.25pt'>III. <span
                        style='display:none'><span style='mso-spacerun:yes'> </span>EDUCATIONAL
  BACKGROUND</span></td>
            <td class=xl26718037>&nbsp;</td>
            <td class=xl26818037>&nbsp;</td>
            <td class=xl26918037>&nbsp;</td>
            <td class=xl26918037>&nbsp;</td>
            <td class=xl26918037>&nbsp;</td>
            <td class=xl26918037>&nbsp;</td>
            <td class=xl26918037>&nbsp;</td>
            <td colspan=6 class=xl27018037 width=358 style='border-right:1.0pt solid black;
  width:269pt'><span
                        style='mso-spacerun:yes'>                                                                                                                               </span></td>
        </tr>
        <tr height=16 style='height:12.0pt'>
            <td rowspan=2 height=32 class=xl27218037 style='height:24.0pt'>26.</td>
            <td colspan=2 rowspan=3 class=xl27218037>LEVEL</td>
            <td colspan=3 rowspan=3 class=xl27418037 width=134 style='border-right:.5pt solid black;
  width:101pt'>NAME OF SCHOOL<span
                        style='mso-spacerun:yes'>                                                                                                                                        </span></td>
            <td colspan=3 rowspan=3 class=xl27418037 width=123 style='border-right:1.0pt solid black;
  border-bottom:.5pt solid black;width:93pt'>BASIC EDUCATION/ DEGREE/
                COURSE<span
                        style='mso-spacerun:yes'>                                                                   </span></td>
            <td colspan=2 rowspan=2 class=xl27518037 width=85 style='border-right:1.0pt solid black;
  border-bottom:.5pt solid black;width:64pt'>PERIOD OF ATTENDANCE</td>
            <td rowspan=3 class=xl34018037 width=92 style='border-top:none;width:69pt'>HIGHEST
                LEVEL/ UNITS EARNED<span style='mso-spacerun:yes'>       </span><br>
            </td>
            <td rowspan=3 class=xl27818037 width=79 style='border-top:none;width:59pt'>YEAR
                GRADUATED<span style='mso-spacerun:yes'>     </span></td>
            <td rowspan=3 class=xl27918037 width=80 style='border-top:none;width:60pt'>SCHOLARSHIP/
                ACADEMIC HONORS RECEIVED</td>
        </tr>
        <tr height=16 style='height:12.0pt'>
        </tr>
        <tr height=18 style='height:13.5pt'>
            <td height=18 class=xl18618037 style='height:13.5pt'>&nbsp;</td>
            <td class=xl29118037 width=41 style='border-top:none;width:31pt'>From</td>
            <td class=xl29218037 width=44 style='border-top:none;border-left:none;
  width:33pt'>To</td>
        </tr>
        <tr height=18 style='height:13.5pt'>
            <td height=18 class=xl29318037 width=17 style='height:13.5pt;border-top:none;
  width:13pt'>&nbsp;</td>
            <td class=xl29418037 width=76 style='width:57pt'>ELEMENTARY</td>
            <td class=xl29518037 width=56 style='width:42pt'>&nbsp;</td>
            <td colspan=3 class=xl29618037 width=134 style='width:101pt'>&nbsp;</td>
            <td colspan=3 class=xl29818037 width=123 style='border-right:.5pt solid black;
  border-left:none;width:93pt'>&nbsp;</td>
            <td class=xl6718037 width=41 style='border-left:none;width:31pt'>&nbsp;</td>
            <td class=xl6718037 width=44 style='border-left:none;width:33pt'>&nbsp;</td>
            <td class=xl30118037 width=92 style='border-left:none;width:69pt'>&nbsp;</td>
            <td class=xl30218037 width=79 style='border-left:none;width:59pt'>&nbsp;</td>
            <td class=xl30318037 width=80 style='border-left:none;width:60pt'>&nbsp;</td>
        </tr>
        <tr height=18 style='height:13.5pt'>
            <td height=18 class=xl29318037 width=17 style='height:13.5pt;border-top:none;
  width:13pt'>&nbsp;</td>
            <td class=xl29418037 width=76 style='width:57pt'>SECONDARY</td>
            <td class=xl29518037 width=56 style='width:42pt'>&nbsp;</td>
            <td colspan=3 class=xl29618037 width=134 style='width:101pt'>&nbsp;</td>
            <td colspan=3 class=xl29818037 width=123 style='border-right:.5pt solid black;
  border-left:none;width:93pt'>&nbsp;</td>
            <td class=xl6718037 width=41 style='border-top:none;border-left:none;
  width:31pt'>&nbsp;</td>
            <td class=xl6718037 width=44 style='border-top:none;border-left:none;
  width:33pt'>&nbsp;</td>
            <td class=xl30118037 width=92 style='border-top:none;border-left:none;
  width:69pt'>&nbsp;</td>
            <td class=xl30118037 width=79 style='border-top:none;border-left:none;
  width:59pt'>&nbsp;</td>
            <td class=xl30318037 width=80 style='border-top:none;border-left:none;
  width:60pt'>&nbsp;</td>
        </tr>
        <tr height=31 style='mso-height-source:userset;height:23.25pt'>
            <td height=31 class=xl29318037 width=17 style='height:23.25pt;border-top:
  none;width:13pt'>&nbsp;</td>
            <td colspan=2 class=xl34918037 width=132 style='border-right:.5pt solid black;
  width:99pt'>VOCATIONAL/ TRADE COURSE</td>
            <td colspan=3 class=xl30418037 width=134 style='width:101pt'>&nbsp;</td>
            <td colspan=3 class=xl30618037 width=123 style='border-right:.5pt solid black;
  border-left:none;width:93pt'>&nbsp;</td>
            <td class=xl6718037 width=41 style='border-top:none;border-left:none;
  width:31pt'>&nbsp;</td>
            <td class=xl6718037 width=44 style='border-top:none;border-left:none;
  width:33pt'>&nbsp;</td>
            <td class=xl30118037 width=92 style='border-top:none;border-left:none;
  width:69pt'>&nbsp;</td>
            <td class=xl30218037 width=79 style='border-top:none;border-left:none;
  width:59pt'>&nbsp;</td>
            <td class=xl30318037 width=80 style='border-top:none;border-left:none;
  width:60pt'>&nbsp;</td>
        </tr>
        <tr height=18 style='height:13.5pt'>
            <td height=18 class=xl29318037 width=17 style='height:13.5pt;border-top:none;
  width:13pt'>&nbsp;</td>
            <td class=xl29418037 width=76 style='border-top:none;width:57pt'>COLLEGE</td>
            <td class=xl29518037 width=56 style='border-top:none;width:42pt'>&nbsp;</td>
            <td colspan=3 class=xl29618037 width=134 style='width:101pt'>&nbsp;</td>
            <td colspan=3 class=xl29818037 width=123 style='border-right:.5pt solid black;
  border-left:none;width:93pt'>&nbsp;</td>
            <td class=xl6718037 width=41 style='border-top:none;border-left:none;
  width:31pt'>&nbsp;</td>
            <td class=xl6718037 width=44 style='border-top:none;border-left:none;
  width:33pt'>&nbsp;</td>
            <td class=xl30118037 width=92 style='border-top:none;border-left:none;
  width:69pt'>&nbsp;</td>
            <td class=xl30118037 width=79 style='border-top:none;border-left:none;
  width:59pt'>&nbsp;</td>
            <td class=xl30318037 width=80 style='border-top:none;border-left:none;
  width:60pt'>&nbsp;</td>
        </tr>
        <tr height=19 style='height:14.25pt'>
            <td height=19 class=xl29418037 width=17 style='height:14.25pt;border-top:
  none;width:13pt'>&nbsp;</td>
            <td class=xl15418037 colspan=2 style='border-right:.5pt solid black'>GRADUATE
                STUDIES<span style='mso-spacerun:yes'> </span></td>
            <td colspan=3 class=xl30918037 width=134 style='width:101pt'>&nbsp;</td>
            <td colspan=3 class=xl31118037 width=123 style='border-right:.5pt solid black;
  border-left:none;width:93pt'>&nbsp;</td>
            <td class=xl31418037 width=41 style='border-top:none;border-left:none;
  width:31pt'>&nbsp;</td>
            <td class=xl31418037 width=44 style='border-top:none;border-left:none;
  width:33pt'>&nbsp;</td>
            <td class=xl31518037 width=92 style='border-top:none;border-left:none;
  width:69pt'>&nbsp;</td>
            <td class=xl31518037 width=79 style='border-top:none;border-left:none;
  width:59pt'>&nbsp;</td>
            <td class=xl31618037 width=80 style='border-top:none;border-left:none;
  width:60pt'>&nbsp;</td>
        </tr>
        <tr height=7 style='mso-height-source:userset;height:5.25pt'>
            <td height=7 class=xl31718037 style='height:5.25pt'>&nbsp;</td>
            <td class=xl31818037>&nbsp;</td>
            <td class=xl31818037>&nbsp;</td>
            <td class=xl31818037>&nbsp;</td>
            <td class=xl31818037>&nbsp;</td>
            <td class=xl31818037>&nbsp;</td>
            <td class=xl31818037>&nbsp;</td>
            <td class=xl31818037>&nbsp;</td>
            <td class=xl31818037>&nbsp;</td>
            <td class=xl31818037>&nbsp;</td>
            <td class=xl31818037>&nbsp;</td>
            <td class=xl31818037>&nbsp;</td>
            <td class=xl31818037>&nbsp;</td>
            <td class=xl31918037>&nbsp;</td>
        </tr>
        <tr height=19 style='height:14.25pt'>
            <td colspan=3 height=19 class=xl32018037 width=149 style='border-right:1.0pt solid black;
  height:14.25pt;width:112pt'>SIGNATURE</td>
            <td class=xl32318037 width=62 style='border-left:none;width:47pt'>&nbsp;</td>
            <td class=xl32418037 width=35 style='width:26pt'>&nbsp;</td>
            <td class=xl32418037 width=37 style='width:28pt'>&nbsp;</td>
            <td class=xl32518037 width=51 style='width:38pt'>&nbsp;</td>
            <td class=xl32618037 style='border-left:none'>DATE</td>
            <td colspan=3 class=xl32718037 style='border-right:1.0pt solid black;
  border-left:none'>&nbsp;</td>
            <td colspan=3 class=xl33018037 style='border-right:1.0pt solid black;
  border-left:none'><span style='mso-spacerun:yes'>  </span>CS FORM 212
                (Revised 2017), Page 1 of 5</td>
        </tr>
        <![if supportMisalignedColumns]>
        <tr height=0 style='display:none'>
            <td width=17 style='width:13pt'></td>
            <td width=76 style='width:57pt'></td>
            <td width=56 style='width:42pt'></td>
            <td width=62 style='width:47pt'></td>
            <td width=35 style='width:26pt'></td>
            <td width=37 style='width:28pt'></td>
            <td width=51 style='width:38pt'></td>
            <td width=50 style='width:38pt'></td>
            <td width=22 style='width:17pt'></td>
            <td width=41 style='width:31pt'></td>
            <td width=44 style='width:33pt'></td>
            <td width=92 style='width:69pt'></td>
            <td width=79 style='width:59pt'></td>
            <td width=80 style='width:60pt'></td>
        </tr>
        <![endif]>
    </table>

</div>


<!----------------------------->
<!--END OF OUTPUT FROM EXCEL PUBLISH AS WEB PAGE WIZARD-->
<!----------------------------->
</body>

</html>
