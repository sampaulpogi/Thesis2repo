<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class empvolu extends Model
{
    //
}
